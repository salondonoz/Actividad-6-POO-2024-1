
package poo.ejerciciocontactos;

public class EjercicioContactos {

    public static void main(String[] args) {
        VentanaContactos interfaz = new VentanaContactos();
        interfaz.setVisible(true);
    }
}
